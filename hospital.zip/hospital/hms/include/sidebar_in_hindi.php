<div class="sidebar app-aside" id="sidebar">
				<div class="sidebar-container perfect-scrollbar">

<nav>
						
						<!-- start: MAIN NAVIGATION MENU -->
						<!-- <div class="navbar-title">
							<span>Main Navigation</span>
						</div> -->
						<ul class="main-navigation-menu">
							<li>
								<a href="dashboard.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> डैशबोर्ड </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="doctor-expand-profile.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> डॉक्टरों को खोजें </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="http://iotsmartbox.000webhostapp.com/thingspeakgraph.html">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> रिपोर्ट देखें </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="send-reports.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-pencil-alt"></i>
										</div>
										<div class="item-inner">
											<span class="title"> रिपोर्ट भेजें </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="reply-history.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-pencil-alt"></i>
										</div>
										<div class="item-inner">
											<span class="title"> डॉक्टर जवाब देते हैं </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="book-appointment.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-pencil-alt"></i>
										</div>
										<div class="item-inner">
											<span class="title"> निर्धारित तारीख बुक करना </span>
										</div>
									</div>
								</a>
							</li>

							<li>
								<a href="appointment-history.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> नियुक्ति का इतिहास </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="report-history.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> रिपोर्ट इतिहास </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="manage-medhistory.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> चिकित्सा का इतिहास </span>
										</div>
									</div>
								</a>
							</li>

						</ul>
						<!-- end: CORE FEATURES -->
						
					</nav>
					</div>
			</div>