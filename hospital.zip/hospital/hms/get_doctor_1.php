<?php
include('include/config.php');
if(!empty($_POST["cityid"])) 
{

 $sql=mysqli_query($con,"select specilization,id from doctors where city='".$_POST['cityid']."'");?>
 <option selected="selected">Select Doctor </option>
 <?php
 while($row=mysqli_fetch_array($sql))
 	{?>
  <option value="<?php echo htmlentities($row['id']); ?>"><?php echo htmlentities($row['specilization']); ?></option>
  <?php
}
}


if(!empty($_POST["doctor"])) 
{

 $sql=mysqli_query($con,"select doctorName from doctors where id='".$_POST['doctor']."'");
 while($row=mysqli_fetch_array($sql))
 	{?>
 <option value="<?php echo htmlentities($row['doctorName']); ?>"><?php echo htmlentities($row['doctorName']); ?></option>
  <?php
}
}

?>

