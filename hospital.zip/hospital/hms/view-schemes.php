<?php
session_start();
error_reporting(0);
//include('include/config.php');
include('include/checklogin.php');
check_login();
  $db = mysqli_connect("localhost", "root", "", "hms");

  $msg = "";
  if (isset($_POST['upload'])) {
  	$image = $_FILES['image']['name'];
  	$image_text = mysqli_real_escape_string($db, $_POST['image_text']);
  	$target = "images/".basename($image);

  	$sql = "INSERT INTO images (image, image_text) VALUES ('$image', '$image_text')";
  	mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  $result = mysqli_query($db, "SELECT * FROM images");
  $cnt=1;
?>
<!DOCTYPE html>
<html>
<head>
<title>Medical Schemes</title>
</head>
<body>
<table class="table table-hover" id="sample-table-1">
										<thead>
											<tr>
												<th class="center">#</th>
												<th class="hidden-xs">Scheme Image</th>			
												<th>Scheme Description</th>
											</tr>
										</thead>
										<tbody>
										<?php 
											while ($row = mysqli_fetch_array($result)) {
										?>
										<tr>
												<td class="center"><?php echo $cnt;?>.</td>
												<td class="hidden-xs"><?php echo "<img width='500px' height='200px' src='doctor/images/".$row['image']."' >";?></td>
												<td><?php echo "<p>".$row['image_text']."</p>";?></td>
											</tr>
											
											<?php 
$cnt=$cnt+1;
											 }?>
											
											
										</tbody>
									</table>
									</body>
</html>