<?php
session_start();
//error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();

if(isset($_POST['submit']))
{
$specilization=$_POST['Doctorspecialization'];
$doctorid=$_POST['doctor'];
$userid=$_SESSION['id'];
$symptoms=$_POST['Moredetails'];
$bp=$_POST['Bloodpressure'];
$bs=$_POST['Bloodsugar'];
$wght=$_POST['Bodyweight'];
$temp=$_POST['Bodytemperature'];
$query=mysqli_query($con,"insert into senddetails(doctorSpecialization,doctorId,userId,moreDetails,bloodPressure,bloodSugar,bodyWeight,bodyTemperature) values('$specilization','$doctorid','$userid','$symptoms','$bp','$bs','$wght','$temp')");
	if($query)
	{
		echo "<script>alert('Your reports successfully send to the selected doctor');</script>";
	}

}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>User  | Send Reports</title>
	
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
		<link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
		<link href="vendor/select2/select2.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
		
		<style type="text/css">
			.inp{
			background: #D3D3D3;
			background-color: #D3D3D3;
			color: #D3D3D3;
			width: 10%;
			padding: 15px;
			font-size: 5px;
			}
			.inp:hover{
			background: #D3D3D3;
			color: #000;
			width: 10%;
			padding: 15px;
			}
		</style>
		
		
		<script>
function getdoctor(val) {
	$.ajax({
	type: "POST",
	url: "get_doctor.php",
	data:'specilizationid='+val,
	success: function(data){
		$("#doctor").html(data);
	}
	});
}
</script>	


<script>
function getfee(val) {
	$.ajax({
	type: "POST",
	url: "get_doctor.php",
	data:'doctor='+val,
	success: function(data){
		$("#fees").html(data);
	}
	});
}
</script>	

<script>
function loadDoc1() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("demo1").value =
      "value";
	  document.getElementById("demoo1").value =
      this.responseText;
    }
  };
  xhttp.open("GET", "https://api.thingspeak.com/channels/788230/fields/1/last.html", true);
  xhttp.send();
}

function loadDoc2() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("demo2").value =
      this.responseText;
	  document.getElementById("demoo2").value =
      this.responseText;
    }
  };
  xhttp.open("GET", "https://api.thingspeak.com/channels/788230/fields/2/last.html", true);
  xhttp.send();
}
function loadDoc3() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("demo3").value =
      this.responseText;
	  document.getElementById("demoo3").value =
      this.responseText;
    }
  };
  xhttp.open("GET", "https://api.thingspeak.com/channels/788230/fields/3/last.html", true);
  xhttp.send();
}
function loadDoc4() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("demo4").value =
      this.responseText;
	  document.getElementById("demoo4").value =
      this.responseText;
    }
  };
  xhttp.open("GET", "https://api.thingspeak.com/channels/788230/fields/4/last.html", true);
  xhttp.send();
}
function loadDoc5() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("demo5").value =
      this.responseText;
	  document.getElementById("demoo5").value =
      this.responseText;
    }
  };
  xhttp.open("GET", "https://api.thingspeak.com/channels/788230/fields/5/last.html", true);
  xhttp.send();
}
function loadDoc6() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("demo6").value =
      this.responseText;
	  document.getElementById("demoo6").value =
      this.responseText;
    }
  };
  xhttp.open("GET", "https://api.thingspeak.com/channels/788230/fields/6/last.html", true);
  xhttp.send();
}


</script>


	
	




	</head>
	<body>
		<div id="app">		
			<?php include('include/sidebar.php');?>
			<div class="app-content">
			
						<?php include('include/header.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">User | Send Reports</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>User</span>
									</li>
									<li class="active">
										<span>Send Reports</span>
									</li>
								</ol>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
							<div class="row">
								<div class="col-md-12">
									
									<div class="row margin-top-30">
										<div class="col-lg-8 col-md-12">
											<div class="panel panel-white">
												<div class="panel-heading">
													<h5 class="panel-title">Send Reports</h5>
												</div>
												<div class="panel-body">
								<p style="color:red;"><?php echo htmlentities($_SESSION['msg1']);?>
								<?php echo htmlentities($_SESSION['msg1']="");?></p>	
													<form role="form" name="book" method="post" id="myform" >
														
														<div class="form-group">
															<label for="DoctorSpecialization">
																Doctor Specialization
															</label>
															<select name="Doctorspecialization" class="form-control" onChange="getdoctor(this.value);">
																<option value="">Select Specialization</option>
<?php $ret=mysqli_query($con,"select * from doctorspecilization");
while($row=mysqli_fetch_array($ret))
{
?>
																<option value="<?php echo htmlentities($row['specilization']);?>">
																	<?php echo htmlentities($row['specilization']);?>
																</option>
																<?php } ?>
																
															</select>
														</div>




														<div class="form-group">
															<label for="doctor">
																Doctors
															</label>
						<select name="doctor" class="form-control" id="doctor" onChange="getfee(this.value);">
						<option value="">Select Doctor</option>
						</select>
														</div>
														
														<div class="form-group">
															<label for="BloodPressure">
																Area Pollution
															</label><br>
															<input type="text" name="Bloodpressure" id="demoo1" class="form-control">
															<div>
																<input type="text" name="btn1" onclick="loadDoc1()" id="demo1" class="inp" placeholder="   value">
															</div>
														</div>
														<div class="form-group">
															<label for="BloodSugar">
																Area Temperature
															</label><br>
															<input type="text" name="Bloodsugar" id="demoo3" class="form-control">
															<div>
																<input type="text" onclick="loadDoc3()" id="demo3" class="inp"  placeholder="   value">
															</div>
														</div>
														<div class="form-group">
															<label for="BodyWeight">
																Area Humidity
															</label><br>
															<input type="text" name="Bodyweight" id="demoo4" class="form-control">
															<div>
																<input type="text" onclick="loadDoc4()" id="demo4" class="inp" placeholder="   value">
															</div>
														</div>
														<div class="form-group">
															<label for="BodyTemperature">
																Body Temperature
															</label><br>
															<input type="text" name="Bodytemperature" id="demoo2" class="form-control">
															<div>
																<input type="text" onclick="loadDoc2()" id="demo2" class="inp" placeholder="   value">
															</div>
														</div>
														<div class="form-group">
															<label for="MoreDetails">
																Symptoms and Parameters
															</label><br>
															<textarea rows="10" cols="50" name="Moredetails" id="speechToText" placeholder="Enter Here...." form="myform"></textarea>
															<!-- <input type="text" name="Moredetails" class="form-control" required="required">   -->
															<span id='message'></span>
														</div><br>															
														<button type="submit" name="submit" class="btn btn-o btn-primary">
															Submit
														</button>
													</form>
												</div>
											</div>
										</div>
											
											</div>
										</div>
									
									</div>
								</div>
							
						<!-- end: BASIC EXAMPLE -->
			
					
					
						
						
					
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<!--<?php include('include/footer.php');?>-->
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>

		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>

<script>
        var message = document.querySelector('#message');

        var SpeechRecognition = SpeechRecognition || webkitSpeechRecognition;
        var SpeechGrammarList = SpeechGrammarList || webkitSpeechGrammarList;

        var grammar = '#JSGF V1.0;'

        var recognition = new SpeechRecognition();
        var speechRecognitionList = new SpeechGrammarList();
        speechRecognitionList.addFromString(grammar, 1);
        recognition.grammars = speechRecognitionList;
        recognition.lang = 'en-US';
        recognition.interimResults = false;

        recognition.onresult = function(event) {
            var last = event.results.length - 1;
            var command = event.results[last][0].transcript;
            
            document.getElementById('speechToText').value = event.results[last][0].transcript;

            
        };

        recognition.onspeechend = function() {
            recognition.stop();
        };

        recognition.onerror = function(event) {
            message.textContent = 'Error occurred in recognition: ' + event.error;
        }        

        document.querySelector('#speechToText').addEventListener('click', function(){
            recognition.start();

        });


    </script>

	</body>
</html>
