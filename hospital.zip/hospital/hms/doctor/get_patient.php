<?php
include('include/config.php');


 $sql=mysqli_query($con,"select fullName,id from users");?>
 <option selected="selected">Select Patient </option>
 <?php
 while($row=mysqli_fetch_array($sql))
 	{?>
  <option value="<?php echo htmlentities($row['id']); ?>"><?php echo htmlentities($row['fullName']); ?></option>
  <?php
}

?>

